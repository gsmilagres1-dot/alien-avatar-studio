export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      avatar_drafts: {
        Row: {
          avatar_url: string
          created_at: string
          id: string
          payment_id: string | null
          prompt_seed: string | null
          user_id: string
          variant_index: number
        }
        Insert: {
          avatar_url: string
          created_at?: string
          id?: string
          payment_id?: string | null
          prompt_seed?: string | null
          user_id: string
          variant_index?: number
        }
        Update: {
          avatar_url?: string
          created_at?: string
          id?: string
          payment_id?: string | null
          prompt_seed?: string | null
          user_id?: string
          variant_index?: number
        }
        Relationships: [
          {
            foreignKeyName: "avatar_drafts_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payment_transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_participants: {
        Row: {
          battle_id: string
          completed_at: string | null
          id: string
          score: number | null
          team_id: string
          user_id: string
        }
        Insert: {
          battle_id: string
          completed_at?: string | null
          id?: string
          score?: number | null
          team_id: string
          user_id: string
        }
        Update: {
          battle_id?: string
          completed_at?: string | null
          id?: string
          score?: number | null
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_participants_battle_id_fkey"
            columns: ["battle_id"]
            isOneToOne: false
            referencedRelation: "battles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "battle_participants_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      battles: {
        Row: {
          active_at: string | null
          bet_fichas: number
          created_at: string
          destination_key: string
          id: string
          status: Database["public"]["Enums"]["battle_status"]
          team_a_id: string
          team_a_score: number
          team_b_id: string | null
          team_b_score: number
          updated_at: string
          winner_team_id: string | null
        }
        Insert: {
          active_at?: string | null
          bet_fichas?: number
          created_at?: string
          destination_key: string
          id?: string
          status?: Database["public"]["Enums"]["battle_status"]
          team_a_id: string
          team_a_score?: number
          team_b_id?: string | null
          team_b_score?: number
          updated_at?: string
          winner_team_id?: string | null
        }
        Update: {
          active_at?: string | null
          bet_fichas?: number
          created_at?: string
          destination_key?: string
          id?: string
          status?: Database["public"]["Enums"]["battle_status"]
          team_a_id?: string
          team_a_score?: number
          team_b_id?: string | null
          team_b_score?: number
          updated_at?: string
          winner_team_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "battles_team_a_id_fkey"
            columns: ["team_a_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "battles_team_b_id_fkey"
            columns: ["team_b_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "battles_winner_team_id_fkey"
            columns: ["winner_team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      ficha_transactions: {
        Row: {
          created_at: string
          delta: number
          id: string
          meta: Json | null
          reason: string
          user_id: string
        }
        Insert: {
          created_at?: string
          delta: number
          id?: string
          meta?: Json | null
          reason: string
          user_id: string
        }
        Update: {
          created_at?: string
          delta?: number
          id?: string
          meta?: Json | null
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      identities: {
        Row: {
          alien_name: string
          avatar_url: string
          birthdate: string
          created_at: string
          galactic_birth: string
          gender: string
          human_name: string
          id: string
          id_number: string
          license_class: string
          payment_id: string | null
          planet_id: string
          rank: string
          ship_category: string | null
          ship_image_url: string | null
          species: string
          updated_at: string
          user_id: string
        }
        Insert: {
          alien_name: string
          avatar_url: string
          birthdate: string
          created_at?: string
          galactic_birth: string
          gender: string
          human_name: string
          id?: string
          id_number: string
          license_class: string
          payment_id?: string | null
          planet_id: string
          rank: string
          ship_category?: string | null
          ship_image_url?: string | null
          species: string
          updated_at?: string
          user_id: string
        }
        Update: {
          alien_name?: string
          avatar_url?: string
          birthdate?: string
          created_at?: string
          galactic_birth?: string
          gender?: string
          human_name?: string
          id?: string
          id_number?: string
          license_class?: string
          payment_id?: string | null
          planet_id?: string
          rank?: string
          ship_category?: string | null
          ship_image_url?: string | null
          species?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "identities_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payment_transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      journeys: {
        Row: {
          attempts_used: number
          completed_at: string | null
          created_at: string
          current_level: number
          final_destination_kind: string | null
          final_destination_name: string | null
          id: string
          identity_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          attempts_used?: number
          completed_at?: string | null
          created_at?: string
          current_level?: number
          final_destination_kind?: string | null
          final_destination_name?: string | null
          id?: string
          identity_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          attempts_used?: number
          completed_at?: string | null
          created_at?: string
          current_level?: number
          final_destination_kind?: string | null
          final_destination_name?: string | null
          id?: string
          identity_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "journeys_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: true
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
        ]
      }
      nave_upgrades: {
        Row: {
          created_at: string
          id: string
          level: number
          updated_at: string
          upgrade_key: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          level?: number
          updated_at?: string
          upgrade_key: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          level?: number
          updated_at?: string
          upgrade_key?: string
          user_id?: string
        }
        Relationships: []
      }
      passports: {
        Row: {
          id: string
          issued_at: string
          level: number
          origin_planet: string
          passport_number: string
          payment_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          id?: string
          issued_at?: string
          level?: number
          origin_planet: string
          passport_number: string
          payment_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          id?: string
          issued_at?: string
          level?: number
          origin_planet?: string
          passport_number?: string
          payment_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      payment_transactions: {
        Row: {
          amount_cents: number
          created_at: string
          credits_granted: number
          credits_remaining: number
          currency: string
          env: string
          id: string
          kind: string
          status: string
          stripe_payment_intent: string | null
          stripe_session_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_cents: number
          created_at?: string
          credits_granted?: number
          credits_remaining?: number
          currency?: string
          env?: string
          id?: string
          kind?: string
          status?: string
          stripe_payment_intent?: string | null
          stripe_session_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_cents?: number
          created_at?: string
          credits_granted?: number
          credits_remaining?: number
          currency?: string
          env?: string
          id?: string
          kind?: string
          status?: string
          stripe_payment_intent?: string | null
          stripe_session_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      quiz_attempts: {
        Row: {
          answers: Json | null
          created_at: string
          destination_id: string | null
          id: string
          journey_id: string | null
          level: number
          passed: boolean
          questions: Json | null
          score: number
          total: number
          user_id: string
        }
        Insert: {
          answers?: Json | null
          created_at?: string
          destination_id?: string | null
          id?: string
          journey_id?: string | null
          level: number
          passed?: boolean
          questions?: Json | null
          score: number
          total: number
          user_id: string
        }
        Update: {
          answers?: Json | null
          created_at?: string
          destination_id?: string | null
          id?: string
          journey_id?: string | null
          level?: number
          passed?: boolean
          questions?: Json | null
          score?: number
          total?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "quiz_attempts_journey_id_fkey"
            columns: ["journey_id"]
            isOneToOne: false
            referencedRelation: "journeys"
            referencedColumns: ["id"]
          },
        ]
      }
      space_map_prizes: {
        Row: {
          claimed_at: string
          id: string
          identity_id: string | null
          image_url: string | null
          prize_id: string
          seals_count: number
          threshold: number
          title: string
          user_id: string
        }
        Insert: {
          claimed_at?: string
          id?: string
          identity_id?: string | null
          image_url?: string | null
          prize_id: string
          seals_count: number
          threshold: number
          title: string
          user_id: string
        }
        Update: {
          claimed_at?: string
          id?: string
          identity_id?: string | null
          image_url?: string | null
          prize_id?: string
          seals_count?: number
          threshold?: number
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_map_prizes_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
        ]
      }
      space_map_seals: {
        Row: {
          difficulty: number
          fichas_earned: number
          id: string
          identity_id: string | null
          issued_at: string
          object_id: string
          object_kind: string
          object_name: string
          score: number
          tier: string
          total: number
          user_id: string
        }
        Insert: {
          difficulty: number
          fichas_earned?: number
          id?: string
          identity_id?: string | null
          issued_at?: string
          object_id: string
          object_kind: string
          object_name: string
          score: number
          tier?: string
          total?: number
          user_id: string
        }
        Update: {
          difficulty?: number
          fichas_earned?: number
          id?: string
          identity_id?: string | null
          issued_at?: string
          object_id?: string
          object_kind?: string
          object_name?: string
          score?: number
          tier?: string
          total?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_map_seals_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
        ]
      }
      team_invites: {
        Row: {
          created_at: string
          created_by: string
          expires_at: string | null
          id: string
          max_uses: number | null
          team_id: string
          token: string
          uses: number
        }
        Insert: {
          created_at?: string
          created_by: string
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          team_id: string
          token: string
          uses?: number
        }
        Update: {
          created_at?: string
          created_by?: string
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          team_id?: string
          token?: string
          uses?: number
        }
        Relationships: [
          {
            foreignKeyName: "team_invites_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_join_requests: {
        Row: {
          created_at: string
          id: string
          message: string | null
          responded_at: string | null
          responded_by: string | null
          status: string
          team_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message?: string | null
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          team_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string | null
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_join_requests_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          id: string
          joined_at: string
          role: Database["public"]["Enums"]["team_role"]
          team_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          role?: Database["public"]["Enums"]["team_role"]
          team_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          role?: Database["public"]["Enums"]["team_role"]
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_members_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          team_id: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          team_id: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_messages_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      teams: {
        Row: {
          country_code: string | null
          created_at: string
          description: string | null
          fichas: number
          flag_emoji: string | null
          id: string
          leader_id: string
          members_count: number
          name: string
          ranking_points: number
          score: number
          updated_at: string
        }
        Insert: {
          country_code?: string | null
          created_at?: string
          description?: string | null
          fichas?: number
          flag_emoji?: string | null
          id?: string
          leader_id: string
          members_count?: number
          name: string
          ranking_points?: number
          score?: number
          updated_at?: string
        }
        Update: {
          country_code?: string | null
          created_at?: string
          description?: string | null
          fichas?: number
          flag_emoji?: string | null
          id?: string
          leader_id?: string
          members_count?: number
          name?: string
          ranking_points?: number
          score?: number
          updated_at?: string
        }
        Relationships: []
      }
      video_ad_claims: {
        Row: {
          created_at: string
          fichas_awarded: number
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          fichas_awarded?: number
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          fichas_awarded?: number
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      visas: {
        Row: {
          destination_id: string
          destination_name: string
          expires_at: string | null
          id: string
          issued_at: string
          journey_id: string | null
          kind: string
          payment_id: string | null
          status: string
          tier: string
          transport: string
          user_id: string
        }
        Insert: {
          destination_id: string
          destination_name: string
          expires_at?: string | null
          id?: string
          issued_at?: string
          journey_id?: string | null
          kind?: string
          payment_id?: string | null
          status?: string
          tier?: string
          transport: string
          user_id: string
        }
        Update: {
          destination_id?: string
          destination_name?: string
          expires_at?: string | null
          id?: string
          issued_at?: string
          journey_id?: string | null
          kind?: string
          payment_id?: string | null
          status?: string
          tier?: string
          transport?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "visas_journey_id_fkey"
            columns: ["journey_id"]
            isOneToOne: false
            referencedRelation: "journeys"
            referencedColumns: ["id"]
          },
        ]
      }
      wallets: {
        Row: {
          alimento_doce: number
          alimento_liquido: number
          alimento_salgado: number
          aneis: number
          created_at: string
          fichas: number
          last_ad_reward_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          alimento_doce?: number
          alimento_liquido?: number
          alimento_salgado?: number
          aneis?: number
          created_at?: string
          fichas?: number
          last_ad_reward_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          alimento_doce?: number
          alimento_liquido?: number
          alimento_salgado?: number
          aneis?: number
          created_at?: string
          fichas?: number
          last_ad_reward_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      mining_state: {
        Row: {
          crashed_count: number
          created_at: string
          landed_count: number
          level: number
          updated_at: string
          user_id: string
        }
        Insert: {
          crashed_count?: number
          created_at?: string
          landed_count?: number
          level?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          crashed_count?: number
          created_at?: string
          landed_count?: number
          level?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      mining_progress: {
        Row: {
          created_at: string
          id: string
          material_key: string
          total_collected: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          material_key: string
          total_collected?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          material_key?: string
          total_collected?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      public_subscribers: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          user_id: string | null
        }
        Insert: {
          avatar_url?: never
          created_at?: string | null
          display_name?: never
          user_id?: string | null
        }
        Update: {
          avatar_url?: never
          created_at?: string | null
          display_name?: never
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      accept_battle: {
        Args: { _battle_id: string; _caller_id: string }
        Returns: undefined
      }
      submit_mining_result: {
        Args: {
          _caller_id: string
          _material_key: string
          _success: boolean
        }
        Returns: Json
      }
      adjust_fichas: {
        Args: {
          _delta: number
          _meta?: Json
          _reason: string
          _user_id: string
        }
        Returns: number
      }
      cancel_join_request: { Args: { _request_id: string }; Returns: undefined }
      claim_video_ad_reward: { Args: never; Returns: Json }
      create_battle: {
        Args: {
          _bet_fichas: number
          _caller_id: string
          _destination_key: string
          _team_a_id: string
          _team_b_id: string
        }
        Returns: string
      }
      create_team: {
        Args: {
          _caller_id: string
          _country_code?: string
          _description?: string
          _flag_emoji?: string
          _name: string
        }
        Returns: string
      }
      expire_battle: { Args: { _battle_id: string }; Returns: string }
      finalize_battle: {
        Args: { _battle_id: string; _caller_id: string }
        Returns: string
      }
      is_team_leader: {
        Args: { _team_id: string; _user_id: string }
        Returns: boolean
      }
      is_team_member: {
        Args: { _team_id: string; _user_id: string }
        Returns: boolean
      }
      join_team_via_invite: {
        Args: { _caller_id: string; _token: string }
        Returns: string
      }
      leave_team: {
        Args: { _caller_id: string; _team_id: string }
        Returns: undefined
      }
      purchase_upgrade: {
        Args: { _caller_id: string; _upgrade_key: string }
        Returns: number
      }
      request_join_team: {
        Args: { _message?: string; _team_id: string }
        Returns: string
      }
      respond_join_request: {
        Args: { _accept: boolean; _request_id: string }
        Returns: undefined
      }
      submit_battle_score:
        | { Args: { _battle_id: string; _score: number }; Returns: undefined }
        | {
            Args: { _battle_id: string; _caller_id?: string; _score: number }
            Returns: undefined
          }
      subscribers_count: { Args: never; Returns: number }
    }
    Enums: {
      battle_status: "pending" | "active" | "finished" | "cancelled"
      team_role: "leader" | "member"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      battle_status: ["pending", "active", "finished", "cancelled"],
      team_role: ["leader", "member"],
    },
  },
} as const
